from flask import Flask, render_template, request, jsonify, redirect, url_for
from monte_carlo import MonteCarlo
import mysql.connector
import pandas as pd
import json
from datetime import datetime
import numpy as np

app = Flask(__name__)

# Konfigurasi database
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'db_lembaga_kesenian'
}

def get_db_connection():
    return mysql.connector.connect(**db_config)

def load_data():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM data_lembaga ORDER BY tahun")
    data = cursor.fetchall()
    cursor.close()
    conn.close()
    return data

@app.route('/')
def index():
    data = load_data()
    # Ubah nama kolom untuk kompatibilitas template
    formatted_data = []
    for item in data:
        formatted_data.append({
            'year': item['tahun'],
            'count': item['jumlah_lembaga']
        })
    return render_template('index.html', data=formatted_data)

@app.route('/data-lembaga')
def data_lembaga():
    data = load_data()
    # Ubah nama kolom untuk kompatibilitas template
    formatted_data = []
    for item in data:
        formatted_data.append({
            'year': item['tahun'],
            'count': item['jumlah_lembaga']
        })
    return render_template('data_lembaga.html', data=formatted_data)

@app.route('/monte-carlo')
def monte_carlo():
    data = load_data()
    return render_template('predictions.html', data=data)

@app.route('/add-data', methods=['POST'])
def add_data():
    try:
        data = request.json
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO data_lembaga (tahun, jumlah_lembaga) VALUES (%s, %s)",
            (data['year'], data['count'])
        )
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/update-data/<int:year>', methods=['PUT'])
def update_data(year):
    try:
        data = request.json
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE data_lembaga SET jumlah_lembaga = %s WHERE tahun = %s",
            (data['count'], year)
        )
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/delete-data/<int:year>', methods=['DELETE'])
def delete_data(year):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM data_lembaga WHERE tahun = %s", (year,))
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = load_data()
        df = pd.DataFrame(data)
        
        mc = MonteCarlo()
        prediction = mc.predict(df)
        
        # Simpan hasil simulasi
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO hasil_simulasi 
               (tahun_prediksi, hasil_prediksi, probabilitas_naik, 
                probabilitas_turun, probabilitas_stabil, intervals)
               VALUES (%s, %s, %s, %s, %s, %s)""",
            (
                datetime.now().year + 1,
                prediction,
                mc.get_probability()['increase'],
                mc.get_probability()['decrease'],
                mc.get_probability()['stable'],
                json.dumps(mc.get_intervals())
            )
        )
        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({
            'prediction': prediction,
            'probability': mc.get_probability(),
            'intervals': mc.get_intervals()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Tambahkan route untuk logout
@app.route('/logout')
def logout():
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5001, debug=True)
