import numpy as np
import pandas as pd
from datetime import datetime

class MonteCarlo:
    def __init__(self, iterations=1000):
        self.iterations = iterations
        self.last_prediction = None
        self.last_probability = None
        self.last_intervals = None

    def predict(self, df):
        # Convert DataFrame jika input adalah dict
        if isinstance(df, list):
            df = pd.DataFrame(df)

        values = np.array(df['jumlah_lembaga'].astype(float))
        years = np.array(df['tahun'])
        
        # Hitung perubahan tahunan
        changes = np.diff(values) / values[:-1]
        
        # Tambahkan noise untuk variasi
        noise = np.random.normal(0, 0.01, len(changes))
        changes = changes + noise
        
        # Generate predictions
        predictions = []
        last_value = values[-1]
        
        for _ in range(self.iterations):
            # Gunakan weighted random choice untuk memberikan bobot lebih pada data terbaru
            weights = np.exp(np.linspace(-1, 0, len(changes)))
            weights = weights / sum(weights)
            
            change = np.random.choice(changes, p=weights)
            
            # Tambahkan random noise untuk variasi
            noise = np.random.normal(0, 0.02)
            change = change + noise
            
            # Batasi perubahan maksimum
            change = np.clip(change, -0.5, 0.5)
            
            prediction = last_value * (1 + change)
            
            # Pastikan prediksi masuk akal
            prediction = max(prediction, last_value * 0.5)  # Tidak turun lebih dari 50%
            prediction = min(prediction, last_value * 2)    # Tidak naik lebih dari 100%
            
            predictions.append(prediction)
        
        # Hitung prediksi akhir
        self.last_prediction = int(np.median(predictions))  # Gunakan median untuk mengurangi pengaruh outlier
        self.last_probability = self._calculate_probability(predictions, last_value)
        self.last_intervals = self._calculate_intervals(predictions)
        
        return self.last_prediction

    def _calculate_probability(self, predictions, last_value):
        predictions = np.array(predictions)
        return {
            'increase': float((predictions > last_value).mean()),
            'decrease': float((predictions < last_value).mean()),
            'stable': float((predictions == last_value).mean())
        }

    def _calculate_intervals(self, predictions):
        intervals = []
        for p in [0.1, 0.25, 0.5, 0.75, 0.9]:
            intervals.append({
                'percentile': int(p * 100),
                'value': int(np.percentile(predictions, p * 100))
            })
        return intervals

    def get_probability(self):
        return self.last_probability

    def get_intervals(self):
        return self.last_intervals