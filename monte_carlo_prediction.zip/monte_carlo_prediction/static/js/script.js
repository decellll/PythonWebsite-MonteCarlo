// Global variables untuk menyimpan data chart
let predictionChart = null;

// Function untuk menampilkan form tambah data
function showAddForm() {
    const modal = document.getElementById('add-modal');
    if (modal) {
        modal.style.display = 'block';
    } else {
        alert('Form tambah data akan ditampilkan di sini');
    }
}

// Function untuk menutup modal
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

// Function untuk menampilkan form edit data
function editData(year) {
    const modal = document.getElementById('edit-modal');
    if (modal) {
        document.getElementById('edit-year').value = year;
        // Ambil data count dari tabel berdasarkan tahun
        const countCell = document.querySelector(`tr[data-year="${year}"] td:nth-child(3)`);
        if (countCell) {
            document.getElementById('edit-count').value = countCell.textContent;
        }
        modal.style.display = 'block';
    } else {
        alert(`Edit data tahun ${year}`);
    }
}

// Function untuk menghapus data
function deleteData(year) {
    if (confirm(`Apakah Anda yakin ingin menghapus data tahun ${year}?`)) {
        // Implementasi penghapusan data
        fetch(`/delete-data/${year}`, {
            method: 'DELETE',
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Data berhasil dihapus');
                window.location.reload();
            } else {
                alert('Gagal menghapus data');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Terjadi kesalahan saat menghapus data');
        });
    }
}

// Function untuk logout
function logout() {
    if (confirm('Anda yakin ingin keluar?')) {
        window.location.href = '/logout';
    }
}

// Function untuk menjalankan simulasi Monte Carlo
async function runSimulation() {
    try {
        // Tampilkan loading state
        const simulateButton = document.getElementById('simulate-button');
        if (simulateButton) {
            simulateButton.disabled = true;
            simulateButton.textContent = 'Memproses...';
        }

        const response = await fetch('/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        
        // Update hasil prediksi
        updatePredictionResults(data);
        
        // Update visualisasi
        updateVisualization(data);

    } catch (error) {
        console.error('Error running simulation:', error);
        alert('Terjadi kesalahan saat menjalankan simulasi. Silakan coba lagi.');
    } finally {
        // Reset loading state
        const simulateButton = document.getElementById('simulate-button');
        if (simulateButton) {
            simulateButton.disabled = false;
            simulateButton.textContent = 'Jalankan Simulasi';
        }
    }
}

// Function untuk update hasil prediksi
function updatePredictionResults(data) {
    // Update prediction result
    const predictionElement = document.getElementById('prediction-result');
    if (predictionElement) {
        predictionElement.textContent = `Prediksi jumlah lembaga: ${data.prediction}`;
    }

    // Update probability information
    const probabilityElement = document.getElementById('probability-info');
    if (probabilityElement) {
        const probabilities = data.probability;
        probabilityElement.innerHTML = `
            <div class="probability-item">
                <span class="label">Probabilitas Naik:</span>
                <span class="value">${(probabilities.increase * 100).toFixed(1)}%</span>
            </div>
            <div class="probability-item">
                <span class="label">Probabilitas Turun:</span>
                <span class="value">${(probabilities.decrease * 100).toFixed(1)}%</span>
            </div>
            <div class="probability-item">
                <span class="label">Probabilitas Stabil:</span>
                <span class="value">${(probabilities.stable * 100).toFixed(1)}%</span>
            </div>
        `;
    }

    // Update intervals
    const intervalsElement = document.getElementById('intervals-info');
    if (intervalsElement) {
        const intervalsList = data.intervals.map(interval => 
            `<div class="interval-item">
                <span class="label">Persentil ${interval.percentile}%:</span>
                <span class="value">${interval.value}</span>
            </div>`
        ).join('');
        intervalsElement.innerHTML = intervalsList;
    }
}

// Function untuk update visualisasi
function updateVisualization(data) {
    if (typeof Plotly === 'undefined') {
        console.warn('Plotly is not loaded');
        return;
    }

    const intervalValues = data.intervals.map(i => i.value);
    const percentiles = data.intervals.map(i => i.percentile);
    
    const trace = {
        x: percentiles,
        y: intervalValues,
        type: 'scatter',
        mode: 'lines+markers',
        name: 'Distribusi Prediksi',
        line: {
            color: 'rgb(31, 119, 180)',
            width: 2
        },
        marker: {
            size: 8,
            color: 'rgb(31, 119, 180)',
            symbol: 'circle'
        }
    };

    const layout = {
        title: {
            text: 'Distribusi Hasil Prediksi Monte Carlo',
            font: {
                size: 24,
                color: '#333'
            }
        },
        xaxis: {
            title: {
                text: 'Persentil',
                font: {
                    size: 16,
                    color: '#666'
                }
            },
            gridcolor: '#ddd'
        },
        yaxis: {
            title: {
                text: 'Jumlah Lembaga',
                font: {
                    size: 16,
                    color: '#666'
                }
            },
            gridcolor: '#ddd'
        },
        paper_bgcolor: 'white',
        plot_bgcolor: 'white',
        margin: {
            l: 60,
            r: 30,
            b: 60,
            t: 80
        }
    };

    const config = {
        responsive: true,
        displayModeBar: true,
        displaylogo: false
    };

    // Jika chart sudah ada, update saja
    if (predictionChart) {
        Plotly.update('prediction-chart', [trace], layout);
    } else {
        // Jika belum ada, buat chart baru
        Plotly.newPlot('prediction-chart', [trace], layout, config)
            .then(chart => {
                predictionChart = chart;
            });
    }
}

// Function untuk handle submit form tambah data
async function handleAddData(event) {
    event.preventDefault();
    const yearInput = document.getElementById('input-year');
    const countInput = document.getElementById('input-count');
    
    const year = yearInput.value;
    const count = countInput.value;

    try {
        const response = await fetch('/add-data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ year, count })
        });

        const data = await response.json();
        
        if (data.success) {
            alert('Data berhasil ditambahkan');
            window.location.reload();
        } else {
            alert(data.message || 'Gagal menambahkan data');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Terjadi kesalahan saat menambahkan data');
    }
}

// Function untuk handle submit form edit data
async function handleEditData(event) {
    event.preventDefault();
    const yearInput = document.getElementById('edit-year');
    const countInput = document.getElementById('edit-count');
    
    const year = yearInput.value;
    const count = countInput.value;

    try {
        const response = await fetch(`/update-data/${year}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ count })
        });

        const data = await response.json();
        
        if (data.success) {
            alert('Data berhasil diperbarui');
            window.location.reload();
        } else {
            alert(data.message || 'Gagal memperbarui data');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Terjadi kesalahan saat memperbarui data');
    }
}

// Event listener saat dokumen sudah siap
document.addEventListener('DOMContentLoaded', function() {
    // Initialize form event listeners
    const addForm = document.getElementById('add-form');
    if (addForm) {
        addForm.addEventListener('submit', handleAddData);
    }

    const editForm = document.getElementById('edit-form');
    if (editForm) {
        editForm.addEventListener('submit', handleEditData);
    }

    // Initialize simulation button
    const simulateButton = document.getElementById('simulate-button');
    if (simulateButton) {
        simulateButton.addEventListener('click', runSimulation);
    }

    // Initialize modal close buttons
    const closeButtons = document.querySelectorAll('.close-modal');
    closeButtons.forEach(button => {
        button.addEventListener('click', () => {
            const modalId = button.closest('.modal').id;
            closeModal(modalId);
        });
    });

    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    });
});